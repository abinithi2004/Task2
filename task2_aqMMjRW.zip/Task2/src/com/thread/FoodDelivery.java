package com.thread;
	class StatusThread extends Thread {
	    public void run() {
	        try {
	            while (true) {
	                System.out.println("Order Status: Cooking...");
	                Thread.sleep(5000);
	            }
	        } catch (Exception e) {}
	    }
	}

	class LocationThread extends Thread {
	    public void run() {
	        try {
	            while (true) {
	                System.out.println("Delivery Boy Location Updating...");
	                Thread.sleep(2000);
	            }
	        } catch (Exception e) {}
	    }
	}

	public class FoodDelivery {
	    public static void main(String[] args) {
	        new StatusThread().start();
	        new LocationThread().start();
	    }
	}
