package com.thread;
	class DownloadThread extends Thread {
	    String fileName;
	    DownloadThread(String fileName) {
	        this.fileName = fileName;
	    }
	    public void run() {
	        try {
	            for (int chunk = 1; chunk <= 5; chunk++) {
	                System.out.println(fileName + ": Downloading chunk " + chunk);
	                Thread.sleep(1000); // simulate time to download chunk
	            }
	            System.out.println(fileName + ": Download Complete!");
	        } catch (Exception e) {}
	    }
	}

	public class Downloader {
	    public static void main(String[] args) {

	        DownloadThread f1 = new DownloadThread("File1");
	        DownloadThread f2 = new DownloadThread("File2");

	        f1.start();
	        f2.start();

	        try {
	            while (f1.isAlive() || f2.isAlive()) {
	                System.out.println("Main Thread: Downloads in progress...");
	                Thread.sleep(1500);
	            }
	        } catch (Exception e) {}

	        System.out.println("Main Thread: All downloads finished.");
	    }
	}


