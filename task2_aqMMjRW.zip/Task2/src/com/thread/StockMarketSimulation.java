package com.thread;
class StockThread extends Thread {
    String stockName;

    StockThread(String name) {
        this.stockName = name;
    }

    public void run() {
        try {
            while (true) {
                int price = 100 + (int)(Math.random() * 50); // random price
                System.out.println(stockName + " Price: " + price);
                Thread.sleep(3000); // updates every 3 sec
            }
        } catch (Exception e) {}
    }
}

public class StockMarketSimulation {
    public static void main(String[] args) {
        
        StockThread t1 = new StockThread("TATA");
        StockThread t2 = new StockThread("RELIANCE");

        t1.start();
        t2.start();

        try {
            while (true) {
                System.out.println("Main Thread: Monitoring Stock Market...");
                Thread.sleep(5000); // every 5 sec
            }
        } catch (Exception e) {}
    }
}

