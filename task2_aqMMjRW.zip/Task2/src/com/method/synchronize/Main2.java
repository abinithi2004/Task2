package com.method.synchronize;
	import java.io.*;
	class BankAccount implements Serializable {
	    int accno; double balance;
	    BankAccount(int a, double b){ accno=a; balance=b; }
	}

	class TransThread extends Thread {
	    BankAccount acc; String file;
	    TransThread(BankAccount a, String f){ acc=a; file=f; }

	    public void run() {
	        try {
	            ObjectOutputStream o =
	                new ObjectOutputStream(new FileOutputStream(file));
	            o.writeObject(acc);
	            o.close();
	            System.out.println("Saved Acc: " + acc.accno);
	        } catch (Exception e) {}
	    }
	}

	public class Main2 {
	    public static void main(String[] args) {
	        new TransThread(new BankAccount(101,5000),"t1.dat").start();
	        new TransThread(new BankAccount(102,7000),"t2.dat").start();
	    }
	}
//method level

