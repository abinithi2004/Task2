package com.method.synchronize;


	import java.io.*;

	// Serializable class
	class Appointment implements Serializable {
	    String doctor, patient, date;

	    Appointment(String d, String p, String dt) {
	        doctor = d;
	        patient = p;
	        date = dt;
	    }
	}

	public class Main3 {
	    public static void main(String[] args) {

	        Appointment appt =
	            new Appointment("Dr. John", "Alice", "15-11-2025");

	        try {
	            ObjectOutputStream oos =
	              new ObjectOutputStream(new FileOutputStream("appointment.dat"));

	            oos.writeObject(appt);   // serialize object
	            oos.close();

	            System.out.println("Appointment Saved!");
	        }
	        catch (Exception e) { }
	    }
	}

//method level synchronization.
