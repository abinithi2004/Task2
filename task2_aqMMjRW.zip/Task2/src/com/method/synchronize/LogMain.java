package com.method.synchronize;
import java.io.*;
//Serializable log object
class LogMessage implements Serializable {
 String message;
 LogMessage(String m) { message = m; }
}

class LoggerSystem {

 // static synchronized log method
 public static synchronized void log(LogMessage log, String file) {
     try {
         ObjectOutputStream oos =
             new ObjectOutputStream(new FileOutputStream(file, true));
         oos.writeObject(log);
         oos.close();
         System.out.println("Logged: " + log.message);
     } catch (Exception e) { }
 }
}

public class LogMain {
 public static void main(String[] args) {
     Thread t = new Thread(() -> {
         for (int i = 1; i <= 5; i++) {
             LoggerSystem.log(new LogMessage("Message " + i), "log.dat");
             try { Thread.sleep(1000); } catch (Exception e) {}
         }
     });
     t.start();
 }
}
//class level