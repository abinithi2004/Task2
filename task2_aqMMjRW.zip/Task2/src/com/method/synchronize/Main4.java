package com.method.synchronize;
	import java.io.*;

	// Serializable Global Configuration
	class ClinicConfig implements Serializable {

	    // static global config values
	    static String hospitalName;
	    static String location;

	    // static method to save config
	    public static void saveConfig(String file) {
	        try {
	            ObjectOutputStream oos =
	                new ObjectOutputStream(new FileOutputStream(file));
	            oos.writeObject(new ClinicConfig());  // saves current static values
	            oos.close();
	            System.out.println("Config Saved!");
	        } catch (Exception e) {}
	    }
	}

	public class Main4 {
	    public static void main(String[] args) {

	        // First instance sets global (static) values
	        ClinicConfig cfg1 = new ClinicConfig();
	        ClinicConfig.hospitalName = "City Hospital";
	        ClinicConfig.location = "Mumbai";

	        clinicShow(); // show config

	        // Save configuration
	        ClinicConfig.saveConfig("config.dat");

	        // Second instance (same static values shared)
	        ClinicConfig cfg2 = new ClinicConfig();
	        clinicShow();
	    }

	    static void clinicShow() {
	        System.out.println("Hospital: " + ClinicConfig.hospitalName);
	        System.out.println("Location: " + ClinicConfig.location);
	    }
	}

//class level