package com.method.synchronize;
import java.io.*;

class FileExporter implements Serializable {
    static Object lock = new Object();   // custom lock

    public static void writeData(String file, Object obj) {
        synchronized (lock) { // synchronized using custom lock
            try (ObjectOutputStream oos =
                 new ObjectOutputStream(new FileOutputStream(file, true))) {
                oos.writeObject(obj);
                System.out.println("Written: " + obj);
            } catch (Exception e) {}
        }
    }
}

class Data implements Serializable {
    String msg;
    Data(String m) { msg = m; }
    public String toString() { return msg; }
}

public class Main6 {
    public static void main(String[] args) {
        Runnable task = () -> {
            Data d = new Data(Thread.currentThread().getName());
            FileExporter.writeData("export.dat", d);
        };

        Thread t1 = new Thread(task, "Thread-1");
        Thread t2 = new Thread(task, "Thread-2");

        t1.start();
        t2.start();
    }
}
//object level

