package com.method.synchronize;
import java.io.*;

class Patient implements Serializable {
 String name;
 int age;
 Patient(String n, int a) { name = n; age = a; }
}


class PatientSave {
 public synchronized void save(Patient p, String file) {
     try {
         ObjectOutputStream oos =
             new ObjectOutputStream(new FileOutputStream(file));
         oos.writeObject(p);     // serialize
         oos.close();
         System.out.println("Saved: " + p.name);
     } catch (Exception e) { }
 }
}

public class Main {
 public static void main(String[] args) {

     PatientSave saver = new PatientSave();

     Patient p1 = new Patient("John", 30);
     Patient p2 = new Patient("Emma", 25);

     
     new Thread(() -> saver.save(p1, "p1.dat")).start();
     new Thread(() -> saver.save(p2, "p2.dat")).start();
 }
} // method level
