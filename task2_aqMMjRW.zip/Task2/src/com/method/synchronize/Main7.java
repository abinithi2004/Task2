package com.method.synchronize;
	import java.io.*;

	// Serializable patient report
	class PatientReport implements Serializable {
	    String name, details;
	    PatientReport(String n, String d) { name = n; details = d; }
	    public String toString() { return name + " - " + details; }
	}

	class HospitalSystem {

	    static String hospital = "City Hospital";
	    static String location = "Chennai";

	    // savepoint mark
	    public static void savepoint(String msg) {
	        System.out.println("== Savepoint: " + msg + " ==");
	    }

	    // save configuration file
	    public static synchronized void saveConfig() {
	        savepoint("Before Saving Config");

	        try (ObjectOutputStream oos =
	             new ObjectOutputStream(new FileOutputStream("config.dat"))) {

	            oos.writeObject(hospital);
	            oos.writeObject(location);
	            System.out.println("Config Saved!");
	        } catch (Exception e) {}
	    }

	    // export patient reports
	    public void exportReport(PatientReport rep) {
	        savepoint("Before Exporting Report");

	        synchronized (this) {
	            try (ObjectOutputStream oos =
	                 new ObjectOutputStream(new FileOutputStream("reports.dat", true))) {

	                oos.writeObject(rep);
	                System.out.println("Report Exported: " + rep);

	            } catch (Exception e) {}
	        }
	    }
	}

	public class Main7 {
	    public static void main(String[] args) {
	        HospitalSystem.saveConfig();

	        HospitalSystem hs = new HospitalSystem();

	        Runnable task = () -> {
	            PatientReport r = new PatientReport(
	                Thread.currentThread().getName(), "General Checkup"
	            );
	            hs.exportReport(r);
	        };

	        new Thread(task, "Patient-1").start();
	        new Thread(task, "Patient-2").start();
	    }
	}

