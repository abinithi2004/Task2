package com.method.synchronize;
	import java.io.*;
	class HospitalStats implements Serializable {
	    static int patientCount;

	    public static synchronized void saveStats() {
	        try (ObjectOutputStream oos =
	             new ObjectOutputStream(new FileOutputStream("stats.dat"))) {
	            oos.writeObject(new HospitalStats());
	            System.out.println("Saved: " + patientCount);
	        } catch (Exception e) {}
	    }
	}

	public class Main5 {
	    public static void main(String[] args) {
	        Thread t1 = new Thread(() -> {
	            HospitalStats.patientCount += 10;
	            HospitalStats.saveStats();
	        });

	        Thread t2 = new Thread(() -> {
	            HospitalStats.patientCount += 5;
	            HospitalStats.saveStats();
	        });

	        t1.start();
	        t2.start();
	    }
	}
//class level

