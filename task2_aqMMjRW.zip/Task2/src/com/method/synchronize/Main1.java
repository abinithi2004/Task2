package com.method.synchronize;
import java.io.*;

//Serializable Doctor class
class Doctor implements Serializable {
 String name;
 String dept;
 Doctor(String n, String d) { name = n; dept = d; }
}

//Thread class → each thread saves one doctor object
class DoctorSaveThread extends Thread {
 Doctor doc;
 String file;

 DoctorSaveThread(Doctor d, String f) {
     doc = d;
     file = f;
 }

 public void run() {
     try {
         ObjectOutputStream oos =
            new ObjectOutputStream(new FileOutputStream(file));
         oos.writeObject(doc);
         oos.close();
         System.out.println("Saved: " + doc.name + " to " + file);
     } catch (Exception e) { }
 }
}

public class Main1 {
 public static void main(String[] args) {

     // Different doctor objects
     Doctor d1 = new Doctor("Dr. John", "Heart");
     Doctor d2 = new Doctor("Dr. Emma", "Brain");
     Doctor d3 = new Doctor("Dr. Sam", "Skin");

     // Non-blocking threads (run in parallel)
     new DoctorSaveThread(d1, "d1.dat").start();
     new DoctorSaveThread(d2, "d2.dat").start();
     new DoctorSaveThread(d3, "d3.dat").start();

     System.out.println("Main thread running without waiting...");
 }
}

//object class
