package com.Exception;
class InsufficientFundsException extends Exception {
 public InsufficientFundsException(String message) {
     super(message);
 }
}
class ATM {
 private double balance;
 public ATM(double balance) {
     this.balance = balance;
 }
 public void withdraw(double amount) throws InsufficientFundsException {

     if (amount > balance) {
         throw new InsufficientFundsException("Alert! Withdrawal amount is greater than available balance.");
     }

     balance -= amount;
     System.out.println("Withdrawal successful! Remaining Balance: " + balance);
 }
}
public class ATMWithdrawal {
 public static void main(String[] args) {
     ATM atm = new ATM(5000);  
     double withdrawAmount = 6000; 
     try {
         atm.withdraw(withdrawAmount);
     } catch (InsufficientFundsException e) {
         System.out.println(e.getMessage());
     }
     System.out.println("Thank you for using the ATM!");
 }
}
