package com.Exception;
	
	class InvalidCardException extends Exception {
	    public InvalidCardException(String message) {
	        super(message);
	    }
	}
	class PaymentGateway{
	    // Method to process payment
	    public void processPayment(String cardNumber, double amount) throws InvalidCardException {

	        // card must be 16 digits
	        if (cardNumber == null || cardNumber.length() != 16 || !cardNumber.matches("\\d+")) {
	            throw new InvalidCardException("Invalid Card Number! Card must be 16 digits long.");
	        }

	        System.out.println("Payment of $" + amount + " processed successfully using card: " + cardNumber);
	    }
	}

	public class OnlinePaymentSystem {

	    public static void main(String[] args) {

	        PaymentGateway gateway = new PaymentGateway();

	        String cardNumber = "12345678";  // invalid card number
	        double amount = 250.00;

	        try {
	            gateway.processPayment(cardNumber, amount);
	        } catch (InvalidCardException e) {
	            System.out.println("Payment Failed: " + e.getMessage());
	        }

	        System.out.println("Thank you for using our payment system!");
	    }
	}


