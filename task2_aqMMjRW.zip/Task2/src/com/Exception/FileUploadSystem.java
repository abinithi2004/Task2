package com.Exception;

	import java.io.*;

	public class FileUploadSystem {

	    
	    public static void uploadFile(String filePath) 
	            throws FileNotFoundException, IOException, SecurityException {

	        // Check if a security rule blocks the file (simple simulation)
	        if (filePath.contains("restricted")) {
	            throw new SecurityException("Security Alert! You cannot upload restricted files.");
	        }

	        File file = new File(filePath);

	        // Check if file exists
	        if (!file.exists()) {
	            throw new FileNotFoundException("File Not Found! Please check the file path.");
	        }

	        // Simulate reading file (uploading)
	        FileInputStream fis = new FileInputStream(file);

	        // If something goes wrong while reading
	        if (fis.read() == -1) {
	            throw new IOException("I/O Error! Unable to read the file.");
	        }

	        System.out.println("File uploaded successfully: " + filePath);

	        fis.close();
	    }

	    public static void main(String[] args) {

	        String path = "restricted_document.txt"; // Try changing this path

	        try {
	            uploadFile(path);
	        } 
	        catch (FileNotFoundException e) {
	            System.out.println(e.getMessage());
	        }
	        catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
	        catch (SecurityException e) {
	            System.out.println(e.getMessage());
	        }

	        System.out.println("File upload process completed.");
	    }
	}

