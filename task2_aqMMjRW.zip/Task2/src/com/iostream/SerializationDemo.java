package com.iostream;
import java.io.*;
class Student implements Serializable {
 private String name;
 private int age;

 // 'transient' → this field will NOT be saved during serialization
 private transient String password;

 public Student(String name, int age, String password) {
     this.name = name;
     this.age = age;
     this.password = password;
 }

 @Override
 public String toString() {
     return "Name: " + name +
            ", Age: " + age +
            ", Password: " + password;  // will be null after deserialization
 }
}

public class SerializationDemo {
 public static void main(String[] args) {

     Student s1 = new Student("John", 20, "secret123");

     // Serialize object
   try (ObjectOutputStream out =new ObjectOutputStream(new FileOutputStream("student.ser"))) {
              
         out.writeObject(s1);
         System.out.println("Object serialized successfully!");

     } catch (IOException e) {
         e.printStackTrace();
     }

     // Deserialize object
     try (ObjectInputStream in =
              new ObjectInputStream(new FileInputStream("student.ser"))) {

         Student s2 = (Student) in.readObject();
         System.out.println("Object deserialized successfully!");
         System.out.println(s2);  // password will be null

     } catch (Exception e) {
         e.printStackTrace();
     }
 }
}
//Description:
//This program demonstrates Java object serialization and
//deserialization using a POJO class that implements the Serializable interface. 
//A Student object is written to a file using ObjectOutputStream and later read back 
//using ObjectInputStream. The transient keyword is used to prevent the password field 
//from being saved, so it becomes null after deserialization. This shows how Java handles 
//persistent storage of objects in a file.
