package com.synchronization;
class Counter {
    private int count = 0;
    // synchronized method → only one thread can run this at a time
    public synchronized void increment() {
        count++;
    }
    public int getCount() {
        return count;
    }
}
class Worker extends Thread {
    Counter counter; //object.
    Worker(Counter counter, String name) {
        super(name);//reference
        this.counter = counter; //constructor and 
    }
    public void run() {
        for (int i = 1; i <= 5; i++) {
            // synchronized method call
            counter.increment();
            System.out.println(getName() + " Incremented → " + counter.getCount());
            // yield() → allow other thread to run
            Thread.yield();
            try {
                // sleep() → pause for 200 ms
                Thread.sleep(200);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }
}
public class SyncMethodsDemo {
    public static void main(String[] args) {
        Counter counter = new Counter();
        Worker t1 = new Worker(counter, "Thread-1");
        Worker t2 = new Worker(counter, "Thread-2");
        System.out.println("Starting threads...");
        t1.start();
        t2.start();
        try {
            // join() → wait for both threads to finish
            t1.join();
            t2.join();
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("Final Counter Value = " + counter.getCount());
        System.out.println("Main Thread Finished.");
    }

}
