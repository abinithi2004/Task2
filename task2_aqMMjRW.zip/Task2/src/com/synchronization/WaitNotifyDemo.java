package com.synchronization;
class SharedData {
    private boolean ready = false;

    // Thread 1 waits until it gets a signal
    public synchronized void waitForSignal() {
        System.out.println("Thread 1: Waiting...");

        while (!ready) {  // Keep waiting until 'ready' becomes true
            try {
                wait();   // Thread goes to WAITING state
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Thread 1: Got the signal! Resuming work...");
    }

    // Thread 2 sends the signal
    public synchronized void sendSignal() {
        System.out.println("Thread 2: Will send signal after 2 seconds...");

        try {
            Thread.sleep(2000); // Delay so Thread 1 waits
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ready = true;
        notify();  // Wake up waiting thread
        System.out.println("Thread 2: Signal sent!");
    }
}

public class WaitNotifyDemo {
    public static void main(String[] args) {
        SharedData data = new SharedData();
        Thread t1 = new Thread(() -> data.waitForSignal());
        Thread t2 = new Thread(() -> data.sendSignal());
        t1.start();
        t2.start();
    }
}

//Description:
//This program demonstrates thread communication using the wait() and notify() methods.
//Thread 1 waits until it receives a signal, while Thread 2 sleeps briefly and then sends the notification.
//Synchronization ensures that only one thread accesses the shared resource at a time, preventing conflicts.